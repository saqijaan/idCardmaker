<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Cards Print</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" media="all">
    <link href="<?php echo e(asset('css/card.css')); ?>" rel="stylesheet" type="text/css" media="all">
    
</head>
<body>
    <button id="printMe">Print </button>
    <div class="print">
            <?php $__currentLoopData = $employes->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <page size="A4">
                    <?php echo $__env->renderEach('backend.user.cards.include.template', $chunk, 'employe', 'backend.user.cards.include.template'); ?>
                </page>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery.print/1.6.0/jQuery.print.js"></script>
    <script>
        $(function(){
            $('#printMe').on("click", function () {
                $('.print').print();
            });
        });
    </script>
</body>
</html>