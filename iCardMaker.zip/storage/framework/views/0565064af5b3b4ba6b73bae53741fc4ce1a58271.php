<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="float-left">
                        All Employes
                    </div>
                    <div class="float-right">
                        <a href="#" class="h2 text-success" id="printMe" title="Print All Cards"><i class="fa fa-print ml-3"></i> </a>
                    </div>
                </div>
                <?php echo $__env->make('layouts.flash_messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="card-body">
                    <div class="print">
                        <?php $__currentLoopData = $employes->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <page size="A4">
                                <?php echo $__env->renderEach('backend.user.cards.include.template', $chunk, 'employe', 'backend.user.cards.include.template'); ?>
                            </page>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function(){
            $('#printMe').on("click", function () {
                $('.print').print();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>