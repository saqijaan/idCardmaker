<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Plugin JavaScript -->
<script src="<?php echo e(asset('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>

<!-- Custom scripts for this template -->
<script src="<?php echo e(asset('assets/js/creative.min.js')); ?>"></script>